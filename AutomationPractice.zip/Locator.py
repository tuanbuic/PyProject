# Locator of HomePage
sign_in = "//a[@class='login']"  # Xpath
contact_us = "Contact us"  # Link Text
# Locator of Authencation Page
create_email_field = "email_create"  # id
Email_field = "email"  # id
password_field = "passwd"  # id
caa_btn = "SubmitCreate"  # name
# Locator of Create Account Page
gender_male = "id_gender1"  # id
genter_femaile = "id_gender2"  # id
firstname_field = "customer_firstname"  # id
lastname_filed = "customer_lastname"  # id
password_field = "passwd"  # id
date_dropdown = "days"  # id
month_dropdown = "months"  # id
year_dropdown = "years"
cus_firstname_field = "firstname"  # id
cus_lastname_field = "lastname"  # id
cus_company_field = "company" #id
cus_address1_field = "address1" #id
cus_address2_field = "address2" #id
cus_city_field = "city" #id
cus_state_dropdown = "id_state" #id
cus_postcode_field ="postcode"
cus_country_Dropdown = "id_country"#id
cus_additional_field = "other"#id
cus_homephone = "phone"#id
cus_mobiphone_field="phone_mobile"#id
cus_allias = "alias"#id
register_btn = "submitAccount"#id
