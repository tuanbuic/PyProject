from selenium.webdriver.common.by import By

from Config.Environment import Enviroment
from Pages.CreateAccountPage import CreateAccount
from Pages.HomePage import HomePage
from Pages.AuthencationPage import Authencation


class TestLogin(Enviroment):
    def test_valid(self):
        driver = self.driver
        #    1. Go to http://automationpractice.com/index.php page.
        driver.get("http://automationpractice.com/index.php")
        lp = HomePage(driver)
        at = Authencation(driver)
        ct = CreateAccount(driver)
        #    2. Click on “sign in” button.
        lp.clickSignin()
        #    3. Input email address into “Email address” field .
        #    4. Click on “create an account” button.
        at.enterCreateEmailField("tcccbc@xyz.com")
        at.clickCreateButton()
        #    5. Fill all personal information.
        #    6. Click on register button.
        ct.CreateAccountFlow("Tuan", "Bui", "123456", "Tuan", "Bui", "Nashtech", "Etown1", "364 Cong Hoa",
                             "Ho Chi Minh","12345", "abccd", "0909090909", "basiu")
