import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

import Locator


class CreateAccount():
    def __init__(self, driver):
        self.driver = driver

    ### Create Element
    def getGenderMaleBtn(self):
        return self.driver.find_element(By.ID, Locator.gender_male)

    def getGenderFemaleBtn(self):
        return self.driver.find_element(By.ID, Locator.genter_femaile)

    def getFirstNameField(self):
        return self.driver.find_element(By.ID, Locator.firstname_field)

    def getLastNameField(self):
        return self.driver.find_element(By.ID, Locator.lastname_filed)

    def getPasswordField(self):
        return self.driver.find_element(By.ID, Locator.password_field)

    def getDateDropdown(self):
        return self.driver.find_element(By.ID, Locator.date_dropdown)

    def getMonthDropdown(self):
        return self.driver.find_element(By.ID, Locator.month_dropdown)

    def getYearDropdown(self):
        return self.driver.find_element(By.ID, Locator.year_dropdown)

    def getCusFirstName(self):
        return self.driver.find_element(By.ID, Locator.cus_firstname_field)

    def getCusLastName(self):
        return self.driver.find_element(By.ID, Locator.cus_lastname_field)

    def getCusCompanyName(self):
        return self.driver.find_element(By.ID, Locator.cus_company_field)

    def getAddress(self):
        return self.driver.find_element(By.ID, Locator.cus_address1_field)

    def getAddressLine2(self):
        return self.driver.find_element(By.ID, Locator.cus_address2_field)

    def getCity(self):
        return self.driver.find_element(By.ID, Locator.cus_city_field)

    def getState(self):
        return self.driver.find_element(By.ID, Locator.cus_state_dropdown)

    def getPostCode(self):
        return self.driver.find_element(By.ID, Locator.cus_postcode_field)

    def getAdditionalInformation(self):
        return self.driver.find_element(By.ID, Locator.cus_additional_field)

    def getHomePhone(self):
        return self.driver.find_element(By.ID, Locator.cus_homephone)

    def getMobilePhone(self):
        return self.driver.find_element(By.ID, Locator.cus_mobiphone_field)

    def getAlias(self):
        return self.driver.find_element(By.ID, Locator.cus_allias)

    def getRegisterBtn(self):
        return self.driver.find_element(By.ID, Locator.register_btn)

    ###Interactive

    def clickGenderMale(self):
        self.getGenderMaleBtn().click()

    def clickGenderFemale(self):
        self.getGenderFemaleBtn().click()

    def enterFirstnameField(self, name):
        self.getFirstNameField().send_keys(name)

    def enterLastnameField(self, name):
        self.getLastNameField().send_keys(name)

    def enterPasswordField(self, password):
        self.getPasswordField().send_keys(password)

    def chooseDateDropdown(self):
        select = Select(self.getDateDropdown())
        select.select_by_index(1)

    def chooseMonthDropdown(self):
        select = Select(self.getMonthDropdown())
        select.select_by_index(1)

    def chooseYearDropdown(self):
        select = Select(self.getYearDropdown())
        select.select_by_index(1)

    def enterCusFirstnameField(self, name):
        self.getCusFirstName().send_keys(name)

    def enterCusLastnameField(self, name):
        self.getCusLastName().send_keys(name)

    def enterCompanyField(self, company):
        self.getCusCompanyName().send_keys(company)

    def enterAddressLine1Field(self, address):
        self.getAddress().send_keys(address)

    def enterAddressLine2Field(self, address):
        self.getAddressLine2().send_keys(address)

    def enterCityField(self, city):
        self.getCity().send_keys(city)

    def chooseStateDropdown(self):
        select = Select(self.getState())
        select.select_by_index(1)

    def enterPostcode(self, number):
        self.getPostCode().send_keys(number)

    def chooseStateDropdown(self):
        select = Select(self.getState())
        select.select_by_visible_text("Alabama")

    def enterAdditionalField(self, p):
        self.getAdditionalInformation().send_keys(p)

    def enterPhoneNumber(self, number):
        self.getMobilePhone().send_keys(number)

    def enterHomePhoneNumber(self, number):
        self.getHomePhone().send_keys(number)

    def enterAlias(self, text):

        self.getAlias().clear()
        self.getAlias().send_keys(text)

    def clickRegisterBtn(self):
        self.getRegisterBtn().click()

    def CreateAccountFlow(self,firstname,lastname,password,cusFirstname,cusLastname,company,address1,address2,city,postcode,additionalText,phone,alias):
        # Click on Gender
        self.clickGenderMale()
        self.enterFirstnameField(firstname)
        time.sleep(2)
        self.enterLastnameField(lastname)
        time.sleep(2)
        self.enterPasswordField(password)
        self.chooseDateDropdown()
        self.chooseMonthDropdown()
        self.chooseYearDropdown()
        self.enterCusFirstnameField(cusFirstname)
        self.enterCusLastnameField(cusLastname)
        self.enterCompanyField(company)
        self.enterAddressLine1Field(address1)
        self.enterAddressLine2Field(address2)
        self.enterCityField(city)
        self.enterPostcode(postcode)
        self.chooseStateDropdown()
        self.enterAdditionalField(additionalText)
        self.enterPhoneNumber(phone)
        self.enterAlias(alias)
        self.clickRegisterBtn()