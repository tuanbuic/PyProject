import selenium
from selenium import webdriver
from selenium.webdriver.common.by import By

import Locator
from Config.Environment import Enviroment


class HomePage():
    def __init__(self, driver):
        self.driver = driver

    def getSignin(self):
        return self.driver.find_element(By.XPATH, Locator.sign_in)
    def getContact(self):
        return self.driver.find_element(By.LINK_TEXT,Locator.contact_us)

    def clickSignin(self):
        self.getSignin().click()
    def clickContact(self):
        self.getContact().click()
