from selenium.webdriver.common.by import By

import Locator


class Authencation():
    def __init__(self, driver):
        self.driver = driver

    def getCreateEmailFiled(self):
        return self.driver.find_element(By.ID, Locator.create_email_field)
    def getCreateBtn(self):
        return self.driver.find_element(By.NAME, Locator.caa_btn)
    def enterCreateEmailField(self, email):
        self.getCreateEmailFiled().send_keys(email)
    def clickCreateButton(self):
        self.getCreateBtn().click()
