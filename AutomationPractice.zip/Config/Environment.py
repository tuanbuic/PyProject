import unittest
from selenium import webdriver
from selenium.webdriver import ChromeOptions


class Enviroment(unittest.TestCase):
    def setUp(self):
        locationdriver = "/Users/tuanbuic/PycharmProjects/AutomationPractice/resources/chromedriver.exe"
        opts = ChromeOptions()
        opts.add_experimental_option("detach", True)
        self.driver = webdriver.Chrome(locationdriver, chrome_options=opts)
        self.driver.implicitly_wait(10)
        self.driver.maximize_window()

#    def teardown(self):
#        self.driver.close()
